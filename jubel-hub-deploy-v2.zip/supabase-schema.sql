-- ─── Jubel Hub Database Schema ───────────────────────────────────────────────
-- Run this entire file in Supabase → SQL Editor → New query

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ─── Users ────────────────────────────────────────────────────────────────────
-- Stores basic user info linked to their Google account
create table if not exists users (
  id          uuid primary key default uuid_generate_v4(),
  email       text unique not null,
  name        text,
  image       text,
  google_id   text unique,
  created_at  timestamptz default now()
);

-- ─── Workstreams ──────────────────────────────────────────────────────────────
-- Persistent projects/initiatives (Snowboxx, Sammy Virji, etc.)
create table if not exists workstreams (
  id            uuid primary key default uuid_generate_v4(),
  user_id       uuid references users(id) on delete cascade,
  name          text not null,
  cat_id        text not null default 'aob',
  status        text not null default 'active',
  owner         text,
  deadline      date,
  link          text,
  notes         text,
  briefing      text,        -- AI-generated bullet point summary (permanent)
  briefing_at   timestamptz,
  context_note  text,        -- Raw pulled context from Drive/Slack/email
  context_at    timestamptz,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

create index if not exists workstreams_user_id_idx on workstreams(user_id);
create index if not exists workstreams_status_idx on workstreams(status);

-- ─── Notes (Prep items) ───────────────────────────────────────────────────────
-- Quick-capture items tagged to workstreams, captured throughout the week
create table if not exists notes (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid references users(id) on delete cascade,
  content     text not null,
  cat_id      text default 'aob',
  ws_id       uuid references workstreams(id) on delete set null,
  person      text,
  priority    text default 'normal',  -- normal | high | fyi
  consumed    boolean default false,  -- true once pulled into an agenda
  created_at  timestamptz default now()
);

create index if not exists notes_user_id_idx on notes(user_id);
create index if not exists notes_consumed_idx on notes(consumed);
create index if not exists notes_ws_id_idx on notes(ws_id);

-- ─── Meetings (Weekly Agendas) ────────────────────────────────────────────────
-- One row per weekly catch-up with Harry
create table if not exists meetings (
  id                uuid primary key default uuid_generate_v4(),
  user_id           uuid references users(id) on delete cascade,
  date              timestamptz not null default now(),
  phase             text default 'build',  -- build | active | complete
  overall_summary   text,
  selected_ws_ids   uuid[],               -- which workstreams in this week's agenda
  synced_at         timestamptz,
  doc_url           text,
  email_at          timestamptz,
  completed_at      timestamptz,
  created_at        timestamptz default now(),
  updated_at        timestamptz default now()
);

create index if not exists meetings_user_id_idx on meetings(user_id);
create index if not exists meetings_phase_idx on meetings(phase);

-- ─── Meeting Workstream Data ──────────────────────────────────────────────────
-- Per-workstream data within each meeting (summary, points, actions, notes)
create table if not exists meeting_ws_data (
  id              uuid primary key default uuid_generate_v4(),
  meeting_id      uuid references meetings(id) on delete cascade,
  ws_id           uuid references workstreams(id) on delete cascade,
  summary         text,           -- editable AI briefing for this meeting
  context_note    text,           -- context pulled this meeting
  meeting_notes   text,           -- live notes captured during meeting
  points          jsonb default '[]',   -- talking points [{id, content, notes, done, rollNote, person, priority, carried}]
  actions         jsonb default '[]',   -- actions [{id, content, owner, status, due, created_at}]
  created_at      timestamptz default now(),
  updated_at      timestamptz default now(),
  unique(meeting_id, ws_id)
);

create index if not exists meeting_ws_data_meeting_id_idx on meeting_ws_data(meeting_id);

-- ─── Meeting Prep Data ────────────────────────────────────────────────────────
-- AOB / untagged prep items pulled into a meeting
create table if not exists meeting_prep_data (
  id            uuid primary key default uuid_generate_v4(),
  meeting_id    uuid references meetings(id) on delete cascade unique,
  context_note  text,
  points        jsonb default '[]',
  created_at    timestamptz default now()
);

-- ─── User Settings ────────────────────────────────────────────────────────────
create table if not exists user_settings (
  user_id       uuid primary key references users(id) on delete cascade,
  harry_email   text default 'harry@jubelbeer.com',
  my_name       text,
  sheet_id      text default '1WVmXCL9mf7zLCT-gRtBCyUu9A7xLlPikkJ5lYYsbuXc',
  drive_folder_id text default '14nv5jcuScSZ_0BkZJ5piaz6_0S2nVQFi',
  updated_at    timestamptz default now()
);

-- ─── Row Level Security ───────────────────────────────────────────────────────
-- Each user can only see their own data

alter table users             enable row level security;
alter table workstreams        enable row level security;
alter table notes              enable row level security;
alter table meetings           enable row level security;
alter table meeting_ws_data    enable row level security;
alter table meeting_prep_data  enable row level security;
alter table user_settings      enable row level security;

-- Users can read/write their own row
create policy "users_own" on users for all using (auth.uid()::text = google_id);

-- Workstreams: user owns their workstreams
create policy "workstreams_own" on workstreams for all using (
  user_id = (select id from users where google_id = auth.uid()::text)
);

-- Notes
create policy "notes_own" on notes for all using (
  user_id = (select id from users where google_id = auth.uid()::text)
);

-- Meetings
create policy "meetings_own" on meetings for all using (
  user_id = (select id from users where google_id = auth.uid()::text)
);

-- Meeting ws data (via meeting ownership)
create policy "meeting_ws_data_own" on meeting_ws_data for all using (
  meeting_id in (
    select id from meetings where user_id = (
      select id from users where google_id = auth.uid()::text
    )
  )
);

-- Meeting prep data
create policy "meeting_prep_data_own" on meeting_prep_data for all using (
  meeting_id in (
    select id from meetings where user_id = (
      select id from users where google_id = auth.uid()::text
    )
  )
);

-- User settings
create policy "user_settings_own" on user_settings for all using (
  user_id = (select id from users where google_id = auth.uid()::text)
);

-- ─── Helpful views ────────────────────────────────────────────────────────────

-- Active workstreams with latest meeting context
create or replace view active_workstreams_summary as
select
  w.*,
  count(n.id) filter (where not n.consumed) as queued_note_count,
  max(m.date) as last_discussed
from workstreams w
left join notes n on n.ws_id = w.id
left join meeting_ws_data mwd on mwd.ws_id = w.id
left join meetings m on m.id = mwd.meeting_id
where w.status in ('active', 'blocked')
group by w.id;

comment on table workstreams is 'Persistent projects and initiatives tracked across weekly catch-ups';
comment on table notes is 'Quick-capture items tagged to workstreams, added throughout the week';
comment on table meetings is 'Weekly catch-up agendas with Harry';
comment on table meeting_ws_data is 'Per-workstream talking points, actions and notes within a meeting';
