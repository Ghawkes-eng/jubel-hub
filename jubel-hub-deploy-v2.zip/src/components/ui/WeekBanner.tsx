'use client'
import { useMemo } from 'react'

export function WeekBanner({ onGoToAgenda, hasAgenda }: { onGoToAgenda: () => void; hasAgenda: boolean }) {
  const { nextCatchup, weekNum, daysUntil } = useMemo(() => {
    const now = new Date()
    const d = new Date(now)
    const day = d.getDay()
    const toMon = day === 1 ? 0 : (8 - day) % 7 || 7
    d.setDate(d.getDate() + toMon)
    d.setHours(16, 0, 0, 0)
    if (toMon === 0 && now > d) d.setDate(d.getDate() + 7)
    const jan1 = new Date(d.getFullYear(), 0, 1)
    const wn = Math.ceil(((d.getTime() - jan1.getTime()) / 86400000 + jan1.getDay() + 1) / 7)
    const du = Math.floor((d.getTime() - Date.now()) / 86400000)
    return { nextCatchup: d, weekNum: wn, daysUntil: du }
  }, [])

  const color = daysUntil <= 0 ? '#a0392a' : daysUntil <= 3 ? '#b5712a' : '#2d6a4f'
  const bg    = daysUntil <= 0 ? '#fce8e4'  : daysUntil <= 3 ? '#fdf3e4'  : '#e8f0e8'
  const label = daysUntil <= 0
    ? 'today at 4pm — go time!'
    : daysUntil === 1
    ? 'tomorrow at 4pm'
    : `in ${daysUntil} days (Mon ${nextCatchup.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}, 4pm)`

  return (
    <div className="rounded-lg px-4 py-3 mb-4 flex items-center gap-3 flex-wrap"
      style={{ background: bg, border: `1px solid ${color}55` }}>
      <div>
        <div className="text-[10px] font-mono uppercase tracking-widest mb-0.5" style={{ color }}>
          Week {weekNum} · Harry × George · every Monday 4pm
        </div>
        <div className="font-semibold text-sm text-ink">
          Next catch-up {label}
        </div>
      </div>
      <div className="flex-1" />
      <a href="https://calendar.google.com/calendar/r" target="_blank" rel="noreferrer"
        className="text-xs px-3 py-1.5 rounded border no-underline"
        style={{ color, borderColor: `${color}66` }}>
        📅 Calendar ↗
      </a>
      <button
        className="text-sm px-4 py-1.5 rounded font-semibold text-cream"
        style={{ background: color }}
        onClick={onGoToAgenda}>
        {hasAgenda ? '▶ Open Weekly Agenda' : '▶ Build this week\'s agenda'}
      </button>
    </div>
  )
}
