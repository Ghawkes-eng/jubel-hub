import Anthropic from '@anthropic-ai/sdk'

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
})

const DRIVE_MCP  = { type: 'url' as const, url: 'https://drivemcp.googleapis.com/mcp/v1',    name: 'google-drive' }
const GMAIL_MCP  = { type: 'url' as const, url: 'https://gmailmcp.googleapis.com/mcp/v1',    name: 'gmail' }
const CAL_MCP    = { type: 'url' as const, url: 'https://calendarmcp.googleapis.com/mcp/v1', name: 'google-calendar' }
const SLACK_MCP  = { type: 'url' as const, url: 'https://mcp.slack.com/mcp',                 name: 'slack' }

type MCPServer = typeof DRIVE_MCP

async function callClaude(prompt: string, mcps: MCPServer[] = []): Promise<string> {
  const body: Parameters<typeof client.messages.create>[0] = {
    model: 'claude-sonnet-4-20250514',
    max_tokens: 2000,
    messages: [{ role: 'user', content: prompt }],
  }

  if (mcps.length) {
    // @ts-ignore — mcp_servers is valid but not yet in SDK types
    body.mcp_servers = mcps
  }

  const response = await client.messages.create(body)
  return response.content
    .filter(b => b.type === 'text')
    .map(b => (b as { type: 'text'; text: string }).text)
    .join('\n')
}

// ─── Exported AI functions ────────────────────────────────────────────────────

export async function pullWsContext(wsName: string, catName: string): Promise<string> {
  return callClaude(
    `Search my Google Drive and Gmail for anything related to "${wsName}" (${catName} at Jubel Beer) from the last 30 days. Return 4-5 clear bullet points of the most relevant recent activity, decisions, or open items.`,
    [DRIVE_MCP, GMAIL_MCP]
  )
}

export async function pullWsSlack(wsName: string): Promise<string> {
  return callClaude(
    `Search Slack for recent messages about "${wsName}" at Jubel Beer in the last 14 days. Return 3-4 bullet points of the key discussions or updates.`,
    [SLACK_MCP]
  )
}

export async function summariseWs(wsName: string, catName: string, contextNote: string, deadline?: string, notes?: string): Promise<string> {
  return callClaude(
    `Write a concise pre-meeting briefing (3-5 bullet points starting with •) for the workstream "${wsName}" at Jubel Beer (${catName}).

Context from Drive, email & Slack:
${contextNote}
${deadline ? `\nDeadline: ${deadline}` : ''}
${notes ? `\nBackground: ${notes}` : ''}

Cover: current status, the key decision or action needed this week, any blockers or deadlines. Max 5 bullets, each under 20 words. No preamble, just the bullets.`
  )
}

export async function generateMeetingSummary(meetingNotes: string, workstreamName?: string): Promise<string> {
  return callClaude(
    `Write a post-meeting summary (2-3 paragraphs) for a weekly 1:1 catch-up at Jubel Beer.

Meeting notes:
${meetingNotes}

Include: key themes and outcomes, decisions made, actions agreed with owners. Professional but warm tone. Max 250 words.`
  )
}

export async function draftCatchupEmail(
  to: string,
  myName: string,
  date: string,
  meetingMarkdown: string
): Promise<string> {
  return callClaude(
    `Create a Gmail draft (do NOT send). To: ${to}. Subject: Catch-up notes — ${date}.

Body: A warm, well-structured summary of our weekly 1:1 catch-up at Jubel Beer. Include:
1. A one-line opener on the key themes
2. Key points and decisions by workstream  
3. Clear actions list with owners and due dates
4. Brief casual sign-off

My name is ${myName}.

Meeting notes to base it on:
${meetingMarkdown}`,
    [GMAIL_MCP]
  )
}

export async function checkNextCatchup(): Promise<string> {
  return callClaude(
    `Find my next upcoming event on Google Calendar with "Harry" in the title or attendees, or any recurring 1:1. Return just the title, date, time and duration — nothing else.`,
    [CAL_MCP]
  )
}

export async function syncToSheet(
  sheetId: string,
  meetingData: {
    id: string
    date: string
    phase: string
    summary: string
    workstreams: Array<{
      name: string
      points: Array<{ content: string; done: string; notes: string }>
      actions: Array<{ content: string; owner: string; status: string; due: string }>
    }>
  }
): Promise<void> {
  const mRow = [meetingData.id, meetingData.date, meetingData.phase, (meetingData.summary || '').replace(/\n/g, ' ')].join(' | ')

  const ptRows = meetingData.workstreams.flatMap(ws =>
    ws.points.map(p => [meetingData.id, ws.name, p.content, p.notes || '', p.done].join(' | '))
  ).join('\n')

  const aRows = meetingData.workstreams.flatMap(ws =>
    ws.actions.map(a => [meetingData.id, ws.name, a.content, a.owner, a.status, a.due || ''].join(' | '))
  ).join('\n')

  await callClaude(
    `Do an UPSERT on Google Sheet ID "${sheetId}" (titled "Weekly Catch-ups with Harry — Master").

For each tab: find rows where meetingId matches "${meetingData.id}", delete them, then insert the new rows.

Tab "Meetings" (meetingId|date|status|summary):
${mRow}

Tab "DiscussionPoints" (meetingId|workstream|content|notes|doneStatus):
${ptRows || '(none)'}

Tab "Actions" (meetingId|workstream|content|owner|status|due):
${aRows || '(none)'}

Create tabs with headers if they don't exist. Confirm briefly.`,
    [DRIVE_MCP]
  )
}
