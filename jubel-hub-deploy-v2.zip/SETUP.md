# Jubel Hub — Setup Guide

## What you'll end up with
A real web app at a URL like `jubel-hub.vercel.app` (or a custom domain).
Sign in with your Jubel Google account → your Notes, Workstreams, and Weekly Agenda are all there, persistent across any device, updating your Sheet automatically.

---

## Prerequisites
- Node.js 18+ (check: `node --version` in Terminal)
- A GitHub account (free) — for deployment
- The credentials from Google Cloud (you already have these)
- A Supabase account (free)
- A Vercel account (free)

---

## Step 1 — Install Node.js (if needed)
Go to https://nodejs.org and download the LTS version. Install it.
Verify: open Terminal and run `node --version` — should show v18 or v20.

---

## Step 2 — Set up Supabase

1. Go to https://supabase.com → sign up (use GitHub login, quickest)
2. Click **New project**:
   - Name: `jubel-hub`
   - Database password: generate a strong one, save it
   - Region: West EU (Ireland)
   - Click **Create new project** — wait ~2 min
3. Once ready, go to **SQL Editor** → **New query**
4. Open the file `supabase-schema.sql` from this project folder
5. Paste the entire contents into the SQL editor → click **Run**
6. You should see "Success" — your database tables are created
7. Go to **Project Settings → API** and copy:
   - **Project URL** (e.g. https://abcdef.supabase.co)
   - **anon/public key** (the long `eyJ...` string under "anon")

---

## Step 3 — Get your Anthropic API key

1. Go to https://console.anthropic.com
2. Click **API Keys** → **Create Key**
3. Copy the key (starts with `sk-ant-...`)
4. You'll need this for the AI features (pull context, summarise, etc.)

---

## Step 4 — Configure environment variables

In the project folder, copy the example env file:
```
cp .env.local.example .env.local
```

Open `.env.local` and fill in all the values:

```
GOOGLE_CLIENT_ID=585998748534-s2dfbeer91k9j0bfkjldt3vnu7v5g28a.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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
NEXTAUTH_SECRET=<generate with: openssl rand -base64 32>
NEXTAUTH_URL=http://localhost:3000
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
ANTHROPIC_API_KEY=sk-ant-your-key
```

To generate NEXTAUTH_SECRET, run this in Terminal:
```
openssl rand -base64 32
```

---

## Step 5 — Install and run locally

```bash
cd jubel-hub
npm install
npm run dev
```

Open http://localhost:3000 in your browser.
Click "Sign in with Google" → sign in with george@jubelbeer.com
You should see the app! ✓

---

## Step 6 — Push to GitHub

1. Go to https://github.com → New repository → name it `jubel-hub` → Private → Create
2. In Terminal, in the project folder:
```bash
git init
git add .
git commit -m "Initial Jubel Hub"
git remote add origin https://github.com/YOUR_USERNAME/jubel-hub.git
git push -u origin main
```

---

## Step 7 — Deploy to Vercel

1. Go to https://vercel.com → sign up with GitHub
2. Click **Add New Project** → import `jubel-hub` from GitHub
3. Before deploying, click **Environment Variables** and add all the same variables from your `.env.local`:
   - GOOGLE_CLIENT_ID
   - GOOGLE_CLIENT_SECRET
   - NEXTAUTH_SECRET
   - NEXTAUTH_URL → **change this to your Vercel URL** e.g. `https://jubel-hub.vercel.app`
   - NEXT_PUBLIC_SUPABASE_URL
   - NEXT_PUBLIC_SUPABASE_ANON_KEY
   - ANTHROPIC_API_KEY
   - SHEET_ID
   - DRIVE_FOLDER_ID
4. Click **Deploy** — takes about 2 minutes
5. Your app is live at `jubel-hub.vercel.app` (or similar)

---

## Step 8 — Add your Vercel URL to Google OAuth

Go back to Google Cloud Console → Google Auth Platform → Clients → click your OAuth client.

Add to **Authorised redirect URIs**:
```
https://jubel-hub.vercel.app/api/auth/callback/google
```

Save. Your sign-in will now work on the live URL.

---

## Adding other Jubel users (V2)

Once you're happy with the app:
1. The `signIn` callback in `src/app/api/auth/[...nextauth]/route.ts` currently allows any `@jubelbeer.com` email
2. Each person who signs in gets their own separate data (workstreams, notes, meetings)
3. No extra setup needed — just share the URL and tell them to sign in with their Jubel Google account

---

## Your existing Sheet
The app is pre-configured to write to your existing Master Sheet:
`1WVmXCL9mf7zLCT-gRtBCyUu9A7xLlPikkJ5lYYsbuXc`
Every time you complete a weekly agenda, it upserts the rows — always the latest data.

---

## Need help?
Come back to this Claude conversation and ask — I can debug, add features, or build new pages.
